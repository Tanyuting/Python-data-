import pandas as pd
import re
import os
import sys
from datetime import datetime, timedelta
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

class EmailAnalyzer:
    def __init__(self, excel_file=None):
        self.excel_file = excel_file
        self.df = None
        self.data_by_search_id = {}
        self.data_by_thread_id = defaultdict(list)
        self.all_emails = []
        self.results = []
        
        if excel_file:
            self.load_data(excel_file)
    
    def load_data(self, excel_file):
        """加载Excel数据"""
        print(f"读取文件: {excel_file}")
        
        if not os.path.exists(excel_file):
            print(f"文件不存在: {excel_file}")
            return False
        
        try:
            self.df = pd.read_excel(excel_file)
            print(f"数据形状: {self.df.shape}")
            print(f"列名: {list(self.df.columns)}")
            
            # 处理数据
            self.process_data()
            return True
            
        except Exception as e:
            print(f"读取文件失败: {e}")
            return False
    
    def process_data(self):
        """处理数据，建立索引"""
        print("\n开始处理数据...")
        
        # 根据提供的邮件格式，直接映射列名
        # 示例数据格式:
        # 列1: 文件名 (如 [mdmswitch_help!15121] Re! 【INC30741042】 【Intune切り替え】問い合わせが入りました_E591.eml)
        # 列2: 日本时间 (2026-03-13 17:32:17)
        # 列3: 发件人 (Kishikawa Nobuhisa (岸川 晋久) <kishikawa.nobuhisa@kk.jp.panasonic.com>)
        # 列4: 收件人/抄送信息
        # 列5: 邮件主题
        # 列6: Message-ID
        # 列7: 文件路径
        
        # 确定列名 - 基于位置和内容
        filename_col = None
        time_col = None
        sender_col = None
        recipient_col = None
        subject_col = None
        message_id_col = None
        filepath_col = None
        
        # 首先尝试精确匹配
        for i, col in enumerate(self.df.columns):
            col_str = str(col).strip()
            col_lower = col_str.lower()
            
            # 根据位置和常见名称识别
            if i == 0 or 'ファイル名' in col_str or 'filename' in col_lower or '件名' in col_str:
                if not filename_col:
                    filename_col = col
                    print(f"识别文件名列: '{col}' (位置: {i+1})")
            
            elif i == 1 or '日本時間' in col_str or 'time' in col_lower or '日時' in col_str:
                if not time_col:
                    time_col = col
                    print(f"识别时间列: '{col}' (位置: {i+1})")
            
            elif i == 2 or '送信者' in col_str or 'sender' in col_lower or '差出人' in col_str or '发件人' in col_str:
                if not sender_col:
                    sender_col = col
                    print(f"识别发件人列: '{col}' (位置: {i+1})")
            
            elif i == 3 or '受信者' in col_str or 'recipient' in col_lower or 'To' in col_str or '宛先' in col_str:
                if not recipient_col:
                    recipient_col = col
                    print(f"识别收件人列: '{col}' (位置: {i+1})")
            
            elif i == 4 or '件名' in col_str or 'subject' in col_lower or 'タイトル' in col_str:
                if not subject_col:
                    subject_col = col
                    print(f"识别主题列: '{col}' (位置: {i+1})")
            
            elif i == 5 or 'message-id' in col_lower or 'メッセージID' in col_str:
                if not message_id_col:
                    message_id_col = col
                    print(f"识别Message-ID列: '{col}' (位置: {i+1})")
        
        # 如果根据名称没找到，使用位置
        if not filename_col and len(self.df.columns) > 0:
            filename_col = self.df.columns[0]
            print(f"使用第一列作为文件名列: {filename_col}")
        
        if not time_col and len(self.df.columns) > 1:
            time_col = self.df.columns[1]
            print(f"使用第二列作为时间列: {time_col}")
        
        if not sender_col and len(self.df.columns) > 2:
            sender_col = self.df.columns[2]
            print(f"使用第三列作为发件人列: {sender_col}")
        
        # 显示最终使用的列
        print(f"\n最终列名配置:")
        print(f"  文件名列: '{filename_col}'")
        print(f"  时间列: '{time_col}'")
        print(f"  发件人列: '{sender_col}'")
        if recipient_col:
            print(f"  收件人列: '{recipient_col}'")
        if subject_col:
            print(f"  主题列: '{subject_col}'")
        if message_id_col:
            print(f"  Message-ID列: '{message_id_col}'")
        
        # 重置数据结构
        self.data_by_search_id = {}
        self.data_by_thread_id = defaultdict(list)
        self.all_emails = []
        
        # 处理每一行数据
        print(f"\n开始处理 {len(self.df)} 行数据...")
        success_count = 0
        skip_count = 0
        
        for idx in range(len(self.df)):
            try:
                row = self.df.iloc[idx]
                
                # 获取文件名
                if filename_col not in row.index:
                    skip_count += 1
                    continue
                    
                filename = row[filename_col]
                if pd.isna(filename) or str(filename).strip() == '':
                    skip_count += 1
                    continue
                
                filename_str = str(filename).strip()
                
                # 获取时间
                time_val = None
                if time_col in row.index:
                    time_str = row[time_col]
                    if pd.notna(time_str):
                        # 处理各种时间格式
                        time_val = self.parse_datetime(time_str)
                
                if time_val is None:
                    skip_count += 1
                    continue
                
                # 获取发件人信息 - 增强解析
                sender = None
                sender_email = None
                sender_name = None
                
                if sender_col and sender_col in row.index:
                    sender_val = row[sender_col]
                    if pd.notna(sender_val):
                        sender_info = self.parse_sender(str(sender_val).strip())
                        sender = sender_info['full']
                        sender_email = sender_info['email']
                        sender_name = sender_info['name']
                
                # 获取收件人/抄送信息
                recipients = []
                if recipient_col and recipient_col in row.index:
                    recipient_val = row[recipient_col]
                    if pd.notna(recipient_val):
                        recipients = self.parse_recipients(str(recipient_val).strip())
                
                # 获取主题
                subject = None
                if subject_col and subject_col in row.index:
                    subject_val = row[subject_col]
                    if pd.notna(subject_val):
                        subject = str(subject_val).strip()
                
                # 获取Message-ID
                message_id = None
                if message_id_col and message_id_col in row.index:
                    message_id_val = row[message_id_col]
                    if pd.notna(message_id_val):
                        message_id = str(message_id_val).strip()
                
                # 获取文件路径
                filepath = None
                if filepath_col and filepath_col in row.index:
                    filepath_val = row[filepath_col]
                    if pd.notna(filepath_val):
                        filepath = str(filepath_val).strip()
                
                # 提取各种ID
                email_id = self.extract_email_id(filename_str)
                thread_id = self.extract_thread_id(filename_str)
                search_id = self.extract_search_id(filename_str)
                inc_number = self.extract_inc_number(filename_str)
                
                # 创建邮件信息对象
                email_info = {
                    '原始行号': idx + 2,
                    '文件名': filename_str,
                    '时间': time_val,
                    '发件人': sender,
                    '发件人邮箱': sender_email,
                    '发件人姓名': sender_name,
                    '收件人列表': recipients,
                    '主题': subject,
                    'Message-ID': message_id,
                    '文件路径': filepath,
                    '邮件ID': email_id if email_id else f"ID_{idx}",
                    '线程ID': thread_id,
                    '搜索ID': search_id,
                    'INC编号': inc_number,
                    '原始数据': row.to_dict()
                }
                
                self.all_emails.append(email_info)
                success_count += 1
                
                # 按搜索ID索引
                if search_id:
                    self.data_by_search_id[search_id] = email_info
                
                # 按线程ID分组
                if thread_id and thread_id != "未知":
                    self.data_by_thread_id[thread_id].append(email_info)
                
                # 如果有多个搜索ID格式，也建立索引
                alt_search_id = self.extract_alt_search_id(filename_str)
                if alt_search_id and alt_search_id != search_id:
                    self.data_by_search_id[alt_search_id] = email_info
                
            except Exception as e:
                skip_count += 1
                continue
        
        # 按时间排序所有邮件
        self.all_emails.sort(key=lambda x: x['时间'])
        
        print(f"\n数据处理完成:")
        print(f"  成功处理: {success_count} 行")
        print(f"  跳过: {skip_count} 行")
        print(f"  有效邮件记录: {len(self.all_emails)}")
        print(f"  唯一线程ID数量: {len(self.data_by_thread_id)}")
        print(f"  包含搜索ID的记录: {len(self.data_by_search_id)}")
        
        # 统计发件人信息
        if sender_col:
            sender_count = len([e for e in self.all_emails if e['发件人']])
            sender_percent = (sender_count / len(self.all_emails)) * 100 if self.all_emails else 0
            print(f"  包含发件人信息的记录: {sender_count} ({sender_percent:.1f}%)")
            
            # 显示一些发件人示例
            if sender_count > 0:
                print(f"\n  发件人示例:")
                unique_senders = set()
                for email in self.all_emails[:10]:
                    if email['发件人'] and email['发件人'] not in unique_senders:
                        unique_senders.add(email['发件人'])
                        email_display = email['发件人'][:50]
                        if email['发件人邮箱']:
                            email_display += f" [{email['发件人邮箱']}]"
                        print(f"    - {email_display}")
        
        # 显示INC编号统计
        inc_count = len([e for e in self.all_emails if e['INC编号']])
        if inc_count > 0:
            print(f"\n  包含INC编号的记录: {inc_count}")
    
    def parse_datetime(self, datetime_str):
        """解析各种格式的日期时间"""
        if pd.isna(datetime_str):
            return None
        
        datetime_str = str(datetime_str).strip()
        
        # 常见的时间格式
        time_formats = [
            '%Y-%m-%d %H:%M:%S',
            '%Y/%m/%d %H:%M:%S',
            '%Y-%m-%d %H:%M',
            '%Y/%m/%d %H:%M',
            '%Y-%m-%d %H:%M:%S.%f',
            '%Y/%m/%d %H:%M:%S.%f',
            '%Y-%m-%dT%H:%M:%S',
            '%Y/%m/%dT%H:%M:%S',
            '%Y%m%d %H:%M:%S',
            '%Y%m%d_%H%M%S',
            '%m/%d/%Y %H:%M',
            '%d/%m/%Y %H:%M',
            '%Y年%m月%d日 %H:%M',
            '%Y年%m月%d日 %H时%M分',
        ]
        
        # 先尝试pandas自动转换
        try:
            return pd.to_datetime(datetime_str)
        except:
            pass
        
        # 尝试各种格式
        for fmt in time_formats:
            try:
                return datetime.strptime(datetime_str, fmt)
            except:
                continue
        
        # 尝试提取数字时间戳
        try:
            numbers = re.findall(r'\d+', datetime_str)
            if numbers and len(numbers[0]) >= 10:
                timestamp = int(numbers[0])
                if timestamp > 1000000000:
                    return datetime.fromtimestamp(timestamp)
        except:
            pass
        
        return None
    
    def parse_sender(self, sender_str):
        """解析发件人信息，提取姓名和邮箱"""
        result = {
            'full': sender_str,
            'name': None,
            'email': None
        }
        
        if not sender_str:
            return result
        
        # 模式1: "姓名 <邮箱>" 格式
        email_in_brackets = re.search(r'<(.+?)>', sender_str)
        if email_in_brackets:
            result['email'] = email_in_brackets.group(1).strip()
            
            # 提取姓名部分
            name_part = sender_str.split('<')[0].strip()
            if name_part:
                # 清理姓名中的括号内容，如 (岸川 晋久)
                name_part = re.sub(r'\([^)]+\)', '', name_part).strip()
                result['name'] = name_part
        
        # 模式2: 直接是邮箱地址
        elif re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', sender_str):
            result['email'] = sender_str
            result['name'] = sender_str.split('@')[0]
        
        # 模式3: 包含邮箱但没有尖括号
        else:
            email_match = re.search(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', sender_str)
            if email_match:
                result['email'] = email_match.group(1)
                
                # 尝试提取姓名
                name_candidate = sender_str.replace(email_match.group(1), '').strip()
                name_candidate = re.sub(r'[<>()\[\]{}]', '', name_candidate).strip()
                if name_candidate:
                    result['name'] = name_candidate
        
        return result
    
    def parse_recipients(self, recipients_str):
        """解析收件人/抄送信息"""
        recipients = []
        
        if not recipients_str:
            return recipients
        
        # 按 | 分割多个收件人
        parts = recipients_str.split('|')
        
        for part in parts:
            part = part.strip()
            if not part:
                continue
            
            # 解析每个收件人
            recipient_info = self.parse_sender(part)
            recipients.append(recipient_info)
        
        return recipients
    
    def extract_sender_id(self, sender_info):
        """从发件人信息中提取唯一标识符"""
        if not sender_info:
            return None
        
        # 如果传入的是字符串，先解析
        if isinstance(sender_info, str):
            parsed = self.parse_sender(sender_info)
            if parsed['email']:
                return parsed['email'].lower()
            return parsed['name'].lower() if parsed['name'] else None
        
        # 如果传入的是字典
        if isinstance(sender_info, dict):
            if sender_info.get('email'):
                return sender_info['email'].lower()
            if sender_info.get('name'):
                return sender_info['name'].lower()
        
        return None
    
    def extract_inc_number(self, filename):
        """从文件名中提取INC编号"""
        if pd.isna(filename) or filename == 'nan':
            return None
        
        filename_str = str(filename)
        
        # 匹配 INC 编号模式
        patterns = [
            r'\[INC(\d+)\]',
            r'INC(\d+)',
            r'【INC(\d+)】',
            r'INC(\d+)\]',
            r'\[INC(\d+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, filename_str)
            if match:
                inc_num = match.group(1)
                if len(inc_num) >= 5:  # INC编号通常较长
                    return f"INC{inc_num}"
        
        return None
    
    def extract_alt_search_id(self, filename):
        """提取其他格式的搜索ID"""
        if pd.isna(filename) or filename == 'nan':
            return None
        
        filename_str = str(filename)
        
        # 匹配 [mdmswitch_help!15121] 格式
        pattern = r'\[(mdmswitch_help!\d+)\]'
        match = re.search(pattern, filename_str)
        if match:
            return match.group(1).replace('!', ':')
        
        return None
    
    def extract_email_id(self, filename):
        """从文件名中提取邮件ID"""
        if pd.isna(filename) or filename == 'nan':
            return None
        
        filename_str = str(filename)
        
        patterns = [
            r'\[.*?:(\d{5})\]',
            r'_(\d{5})\.eml',
            r'(\d{5})\.eml',
            r'\[INC(\d{8})\]',
            r'INC(\d{8})',
            r'(\d{5})_',
            r'_(\d{5})_',
            r':(\d{5})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, filename_str)
            if match:
                return match.group(1)
        
        return None
    
    def extract_thread_id(self, filename):
        """从文件名中提取线程ID"""
        if pd.isna(filename) or filename == 'nan':
            return "未知"
        
        filename_str = str(filename)
        
        # 首先检查是否是长C编号（如C29497931）
        long_c_pattern = r'[^a-zA-Z](C\d{8,})[^a-zA-Z]'
        long_c_match = re.search(long_c_pattern, filename_str)
        if long_c_match:
            return "未知"
        
        # 检查短格式线程ID
        patterns = [
            r'[^a-zA-Z]([A-Z]\d{3})[^\.a-zA-Z]',
            r'_([A-Z]\d{3})\.eml',
            r'問い合わせが入りました_([A-Z]\d{3})\.eml',
            r'【Intune切り替え】問い合わせが入りました_([A-Z]\d{3})\.eml',
            r'([A-Z]\d{3})(?![a-zA-Z\d])',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, filename_str, re.IGNORECASE)
            if match:
                thread_id = match.group(1).upper()
                if (thread_id[0] in 'ABCDEFGH' and 
                    len(thread_id) == 4 and 
                    thread_id[1:].isdigit()):
                    return thread_id
        
        # 检查INC编号
        inc_patterns = [
            r'\[INC(\d+)\]',
            r'INC(\d+)',
            r'【INC(\d+)】',
        ]
        
        for pattern in inc_patterns:
            match = re.search(pattern, filename_str)
            if match:
                inc_num = match.group(1)
                if len(inc_num) >= 5:
                    return f"INC{inc_num}"
        
        return "未知"
    
    def extract_search_id(self, filename):
        """从文件名中提取搜索ID"""
        if pd.isna(filename) or filename == 'nan':
            return None
        
        filename_str = str(filename)
        
        patterns = [
            r'\[(mdmswitch_help:\d+)\]',
            r'\[(mdmswitch_help!\d+)\]',  # 支持 ! 分隔符
            r'\[(\w+:\d+)\]',
            r'(\w+:\d+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, filename_str)
            if match:
                search_id = match.group(1)
                # 统一格式：将 ! 替换为 :
                search_id = search_id.replace('!', ':')
                return search_id
        
        return None
    
    def check_reply_relation(self, email, target_email):
        """
        检查邮件与目标邮件的回复关系
        在同一线程中，只要时间晚于目标邮件，就认为是回复
        返回: (是否是回复, 是否同人)
        """
        if email['时间'] <= target_email['时间']:
            return False, False
        
        # 在同一线程中，时间晚于目标邮件的都算回复
        is_reply = True
        
        # 检查是否为同人回复
        is_same_sender = False
        if email.get('发件人邮箱') and target_email.get('发件人邮箱'):
            if email['发件人邮箱'].lower() == target_email['发件人邮箱'].lower():
                is_same_sender = True
        elif email.get('发件人') and target_email.get('发件人'):
            sender1 = self.extract_sender_id(email['发件人'])
            sender2 = self.extract_sender_id(target_email['发件人'])
            if sender1 and sender2 and sender1 == sender2:
                is_same_sender = True
        
        return is_reply, is_same_sender
    
    def find_closest_response(self, search_id):
        """查找指定搜索ID的最接近回复（包括同人）"""
        print(f"\n查找搜索ID: {search_id}")
        
        # 规范化搜索ID格式
        normalized_search_id = search_id.replace('!', ':')
        
        if normalized_search_id not in self.data_by_search_id:
            # 尝试其他匹配方式
            matching_ids = []
            for sid in self.data_by_search_id.keys():
                if (normalized_search_id.lower() in sid.lower() or 
                    sid.lower() in normalized_search_id.lower()):
                    matching_ids.append(sid)
            
            if not matching_ids:
                print(f"  未找到搜索ID: {search_id}")
                return {
                    '搜索ID': search_id,
                    '目标邮件名包含': '未找到',
                    '目标邮件时间': 'N/A',
                    '目标发件人': 'N/A',
                    '目标发件人邮箱': 'N/A',
                    '最近的返信时间': '未找到邮件',
                    '回复邮件ID': 'N/A',
                    '回复发件人': 'N/A',
                    '回复发件人邮箱': 'N/A',
                    '回复间隔': 'N/A',
                    '回复间隔(小时)': 'N/A',
                    '回复类型': 'N/A',
                    '线程邮件数': 0,
                    '回复邮件数': 0,
                    '同人回复数': 0,
                    '状态': '未找到搜索ID',
                    '备注': ''
                }
            
            print(f"  找到匹配的搜索ID: {matching_ids[0]}")
            normalized_search_id = matching_ids[0]
        
        target_email = self.data_by_search_id[normalized_search_id]
        target_time = target_email['时间']
        target_thread_id = target_email['线程ID']
        target_filename = target_email['文件名']
        target_sender = target_email['发件人']
        target_sender_email = target_email['发件人邮箱']
        
        print(f"  目标邮件: {target_filename[:80]}...")
        print(f"  目标时间: {target_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  目标发件人: {target_sender if target_sender else '未知'}")
        if target_sender_email:
            print(f"  目标发件人邮箱: {target_sender_email}")
        
        # 检查是否有线程ID
        if target_thread_id == "未知" or target_thread_id not in self.data_by_thread_id:
            print(f"  ⚠ 未找到线程中的其他邮件")
            return {
                '搜索ID': search_id,
                '目标邮件名包含': target_thread_id,
                '目标邮件时间': target_time.strftime('%Y-%m-%d %H:%M:%S'),
                '目标发件人': target_sender if target_sender else '未知',
                '目标发件人邮箱': target_sender_email if target_sender_email else '未知',
                '最近的返信时间': '无回复',
                '回复邮件ID': 'N/A',
                '回复发件人': 'N/A',
                '回复发件人邮箱': 'N/A',
                '回复间隔': 'N/A',
                '回复间隔(小时)': 'N/A',
                '回复类型': 'N/A',
                '线程邮件数': 1,
                '回复邮件数': 0,
                '同人回复数': 0,
                '状态': '线程中无其他邮件',
                '备注': ''
            }
        
        thread_emails = self.data_by_thread_id[target_thread_id].copy()
        thread_emails.sort(key=lambda x: x['时间'])
        
        print(f"  找到 {len(thread_emails)} 封同一线程的邮件")
        
        # 显示线程中的邮件时间线
        print(f"  线程 {target_thread_id} 邮件时间线:")
        for i, email in enumerate(thread_emails):
            time_str = email['时间'].strftime('%m-%d %H:%M:%S')
            is_target = " ←目标" if email.get('搜索ID') == normalized_search_id else ""
            sender_display = email['发件人姓名'] if email['发件人姓名'] else (email['发件人'][:20] if email['发件人'] else '未知')
            print(f"    {i+1:3d}. {time_str} 发件人:{sender_display}{is_target}")
        
        # 查找目标邮件之后的所有邮件（同一线程中时间晚于目标邮件的都算回复）
        print(f"\n  查找目标邮件之后的所有邮件...")
        
        all_responses = []
        same_sender_responses = []
        
        for email in thread_emails:
            if email['时间'] > target_time:
                # 同一线程中时间晚于目标邮件的都算回复
                is_reply = True
                is_same_sender = False
                
                # 检查是否为同人回复
                if email.get('发件人邮箱') and target_email.get('发件人邮箱'):
                    if email['发件人邮箱'].lower() == target_email['发件人邮箱'].lower():
                        is_same_sender = True
                elif email.get('发件人') and target_email.get('发件人'):
                    sender1 = self.extract_sender_id(email['发件人'])
                    sender2 = self.extract_sender_id(target_email['发件人'])
                    if sender1 and sender2 and sender1 == sender2:
                        is_same_sender = True
                
                response_data = {
                    'email': email,
                    'is_same_sender': is_same_sender
                }
                all_responses.append(response_data)
                if is_same_sender:
                    same_sender_responses.append(response_data)
        
        print(f"  目标邮件之后的所有邮件: {len(all_responses)} 封")
        if same_sender_responses:
            print(f"  其中同人回复: {len(same_sender_responses)} 封")
        
        if not all_responses:
            print("  ⚠ 目标邮件之后没有邮件")
            return {
                '搜索ID': search_id,
                '目标邮件名包含': target_thread_id,
                '目标邮件时间': target_time.strftime('%Y-%m-%d %H:%M:%S'),
                '目标发件人': target_sender if target_sender else '未知',
                '目标发件人邮箱': target_sender_email if target_sender_email else '未知',
                '最近的返信时间': '无回复',
                '回复邮件ID': 'N/A',
                '回复发件人': 'N/A',
                '回复发件人邮箱': 'N/A',
                '回复间隔': 'N/A',
                '回复间隔(小时)': 'N/A',
                '回复类型': 'N/A',
                '线程邮件数': len(thread_emails),
                '回复邮件数': 0,
                '同人回复数': 0,
                '状态': '无回复',
                '备注': ''
            }
        
        # 显示所有回复的时间差（包括同人）
        print(f"\n  所有回复邮件时间差分析:")
        sorted_responses = sorted(all_responses, key=lambda x: x['email']['时间'] - target_time)
        
        for i, response in enumerate(sorted_responses):
            email = response['email']
            time_diff = email['时间'] - target_time
            time_diff_hours = time_diff.total_seconds() / 3600
            
            days = time_diff.days
            hours = time_diff.seconds // 3600
            minutes = (time_diff.seconds % 3600) // 60
            
            if days > 0:
                interval_str = f"{days}天{hours}小时{minutes}分钟"
            elif hours > 0:
                interval_str = f"{hours}小时{minutes}分钟"
            else:
                interval_str = f"{minutes}分钟"
            
            sender_display = email['发件人姓名'] if email['发件人姓名'] else (email['发件人'][:20] if email['发件人'] else '未知')
            same_sender_mark = " (同人)" if response['is_same_sender'] else ""
            is_nearest = " ←最接近" if i == 0 else ""
            print(f"    {i+1:2d}. {email['时间'].strftime('%m-%d %H:%M:%S')} 发件人:{sender_display}{same_sender_mark} - 间隔: {interval_str} ({time_diff_hours:.2f}小时){is_nearest}")
        
        # 找到时间上最接近的回复（可能是同人）
        nearest_response = sorted_responses[0]
        nearest_email = nearest_response['email']
        time_diff = nearest_email['时间'] - target_time
        total_hours = time_diff.total_seconds() / 3600
        
        days = time_diff.days
        hours = time_diff.seconds // 3600
        minutes = (time_diff.seconds % 3600) // 60
        
        if days > 0:
            interval_str = f"{days}天{hours}小时{minutes}分钟"
        elif hours > 0:
            interval_str = f"{hours}小时{minutes}分钟"
        else:
            interval_str = f"{minutes}分钟"
        
        # 判断回复类型
        reply_type = "同人回复" if nearest_response['is_same_sender'] else "他人回复"
        
        print(f"\n  最近回复时间: {nearest_email['时间'].strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  回复邮件ID: {nearest_email['邮件ID']}")
        print(f"  回复发件人: {nearest_email['发件人'] if nearest_email['发件人'] else '未知'}")
        if nearest_email.get('发件人邮箱'):
            print(f"  回复发件人邮箱: {nearest_email['发件人邮箱']}")
        print(f"  回复类型: {reply_type}")
        print(f"  回复间隔: {interval_str} ({total_hours:.2f}小时)")
        
        if nearest_response['is_same_sender']:
            print(f"  ⚠ 注意: 最近回复为同人回复")
        
        return {
            '搜索ID': search_id,
            '目标邮件名包含': target_thread_id,
            '目标邮件时间': target_time.strftime('%Y-%m-%d %H:%M:%S'),
            '目标发件人': target_sender if target_sender else '未知',
            '目标发件人邮箱': target_sender_email if target_sender_email else '未知',
            '最近的返信时间': nearest_email['时间'].strftime('%Y-%m-%d %H:%M:%S'),
            '回复邮件ID': nearest_email['邮件ID'],
            '回复发件人': nearest_email['发件人'] if nearest_email['发件人'] else '未知',
            '回复发件人邮箱': nearest_email['发件人邮箱'] if nearest_email['发件人邮箱'] else '未知',
            '回复间隔': interval_str,
            '回复间隔(小时)': round(total_hours, 2),
            '回复类型': reply_type,
            '线程邮件数': len(thread_emails),
            '回复邮件数': len(all_responses),
            '同人回复数': len(same_sender_responses),
            '状态': '成功',
            '备注': f'最近回复{"是" if nearest_response["is_same_sender"] else "不是"}同人'
        }
    
    def batch_query(self, search_ids):
        """批量查询多个搜索ID"""
        print(f"\n开始批量处理 {len(search_ids)} 个搜索ID...")
        
        batch_results = []
        
        for i, search_id in enumerate(search_ids):
            print(f"[{i+1}/{len(search_ids)}] ", end="")
            
            result = self.find_closest_response(search_id)
            batch_results.append(result)
            
            if result['状态'] == '成功':
                reply_type = f" ({result['回复类型']})" if result['回复类型'] != 'N/A' else ""
                print(f"  ✓ 找到最近回复: {result['最近的返信时间']} (间隔:{result['回复间隔']}){reply_type}")
            elif result['状态'] == '未找到搜索ID':
                print(f"  ✗ 未找到")
            else:
                print(f"  ⚠ {result['状态']}")
        
        return batch_results

def safe_save_excel_with_auto_rename(df, base_filename=None):
    """安全保存Excel文件"""
    if not base_filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_filename = f"邮件查询结果_{timestamp}"
    
    if not base_filename.endswith('.xlsx'):
        base_filename += '.xlsx'
    
    save_locations = [
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "Downloads"),
        os.path.dirname(os.path.abspath(__file__)),
        "C:\\Temp",
        ".",
    ]
    
    for location in save_locations:
        try:
            if not os.path.exists(location):
                continue
            
            file_path = os.path.join(location, os.path.basename(base_filename))
            
            if os.path.exists(file_path):
                name_part, ext = os.path.splitext(file_path)
                micro_timestamp = datetime.now().strftime("%H%M%S_%f")[:-3]
                file_path = f"{name_part}_{micro_timestamp}{ext}"
            
            df.to_excel(file_path, index=False)
            print(f"✓ 文件保存成功: {file_path}")
            return file_path
            
        except PermissionError:
            continue
        except Exception as e:
            continue
    
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        unique_filename = f"邮件结果_{timestamp}.xlsx"
        df.to_excel(unique_filename, index=False)
        print(f"✓ 文件保存成功: {unique_filename}")
        return unique_filename
    except Exception as e:
        print(f"✗ 保存失败: {e}")
        return None

def main():
    """主程序"""
    print("邮件回复时间分析工具 - 增强版（支持具体邮件格式）")
    print("=" * 80)
    print("功能：支持 [mdmswitch_help!15121] 格式，自动解析发件人姓名和邮箱")
    print("=" * 80)
    
    # 固定文件路径
    excel_file = "C:\\Users\\out-tanyuting\\Desktop\\new\\邮件完整信息0327.xlsx"
    
    if not os.path.exists(excel_file):
        print(f"文件不存在: {excel_file}")
        excel_file = input("请输入Excel文件路径: ").strip()
        if not os.path.exists(excel_file):
            print("文件不存在，程序退出")
            return
    
    print(f"使用文件: {excel_file}")
    
    # 创建分析器对象
    analyzer = EmailAnalyzer(excel_file)
    
    if not analyzer.all_emails:
        print("数据加载失败，请检查文件格式")
        return
    
    # 测试示例
    print(f"\n测试示例: mdmswitch_help:14969 和 mdmswitch_help!15121 格式")
    test_id = 'mdmswitch_help:14969'
    test_id2 = 'mdmswitch_help!15121'
    
    if test_id in analyzer.data_by_search_id:
        result = analyzer.find_closest_response(test_id)
        if result:
            print(f"\n测试结果 (格式1):")
            print(f"  目标邮件: {test_id}")
            print(f"  目标发件人: {result['目标发件人']}")
            print(f"  状态: {result['状态']}")
            if result['状态'] == '成功':
                print(f"  最近回复: {result['最近的返信时间']} (间隔:{result['回复间隔']})")
                print(f"  回复类型: {result['回复类型']}")
    
    if test_id2 in analyzer.data_by_search_id or test_id2.replace('!', ':') in analyzer.data_by_search_id:
        result = analyzer.find_closest_response(test_id2)
        if result:
            print(f"\n测试结果 (格式2 - 带!格式):")
            print(f"  目标邮件: {test_id2}")
            print(f"  目标发件人: {result['目标发件人']}")
            print(f"  状态: {result['状态']}")
            if result['状态'] == '成功':
                print(f"  最近回复: {result['最近的返信时间']} (间隔:{result['回复间隔']})")
                print(f"  回复类型: {result['回复类型']}")
    
    # 主查询循环
    all_results = []
    
    while True:
        print(f"\n{'='*80}")
        print("查询选项:")
        print("1. 按搜索ID查询")
        print("2. 批量查询")
        print("3. 测试示例")
        print("4. 保存并退出")
        print("输入 'quit' 或 'q' 退出")
        
        choice = input("\n请选择 (1-4): ").strip().lower()
        
        if choice in ['quit', 'exit', 'q']:
            break
        
        elif choice == '1':
            user_input = input("\n请输入搜索ID (支持 mdmswitch_help:14969 或 mdmswitch_help!15121 格式): ").strip()
            if not user_input:
                continue
            
            result = analyzer.find_closest_response(user_input)
            if result:
                all_results.append(result)
                
                print(f"\n查询结果:")
                for key, value in result.items():
                    if value not in ['N/A', ''] and value != '未知':
                        print(f"  {key}: {value}")
        
        elif choice == '2':
            print("\n批量查询模式")
            print("输入搜索ID，每行一个，输入空行结束:")
            
            search_ids = []
            while True:
                try:
                    line = input().strip()
                    if line == '':
                        break
                    search_ids.append(line)
                except:
                    break
            
            if search_ids:
                results = analyzer.batch_query(search_ids)
                all_results.extend(results)
                
                if results:
                    df = pd.DataFrame(results)
                    saved_file = safe_save_excel_with_auto_rename(df, "批量查询结果")
                    
                    if saved_file:
                        success = len([r for r in results if r.get('状态') == '成功'])
                        print(f"\n成功: {success}/{len(results)}")
        
        elif choice == '3':
            print("\n测试示例...")
            test_id = 'mdmswitch_help!15121'
            result = analyzer.find_closest_response(test_id)
            if result:
                all_results.append(result)
                print(f"\n测试结果:")
                for key, value in result.items():
                    if value not in ['N/A', '']:
                        print(f"  {key}: {value}")
        
        elif choice == '4':
            if all_results:
                df = pd.DataFrame(all_results)
                saved_file = safe_save_excel_with_auto_rename(df, "最终查询结果")
                
                if saved_file:
                    success = len([r for r in all_results if r['状态'] == '成功'])
                    print(f"\n总查询数: {len(all_results)}, 成功: {success}")
            else:
                print("没有查询结果需要保存")
            
            print("程序退出")
            break

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"程序错误: {e}")
        import traceback
        traceback.print_exc()
    
    input("\n按回车键退出...")