import pandas as pd
import os
from email import policy
from email.parser import BytesParser
from datetime import datetime, timezone, timedelta
import pytz

folder = r"C:\Users\out-tanyuting\Downloads\test-0220"
output = r"C:\Users\out-tanyuting\Desktop\邮件日本时间0220.xlsx"

def parse_date_to_jst(date_str):
    """将邮件Date头转换为日本时间"""
    if not date_str:
        return "无Date信息"
    
    try:
        # 使用email.utils解析日期
        from email.utils import parsedate_tz, mktime_tz
        
        # 解析带时区的日期
        time_tuple = parsedate_tz(date_str)
        if time_tuple:
            # 转换为时间戳（考虑时区）
            timestamp = mktime_tz(time_tuple)
            # 转换为UTC datetime
            utc_time = datetime.fromtimestamp(timestamp, tz=timezone.utc)
            # 转换为日本时间（UTC+9）
            jst_time = utc_time.astimezone(timezone(timedelta(hours=9)))
            return jst_time.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        pass
    
    # 如果上面的方法失败，尝试用dateutil
    try:
        from dateutil import parser
        dt = parser.parse(date_str)
        # 如果dt有时区信息，转换为JST
        if dt.tzinfo:
            jst = dt.astimezone(timezone(timedelta(hours=9)))
        else:
            # 如果没有时区信息，假设是UTC
            jst = dt.replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=9)))
        return jst.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return date_str

def extract_date_from_eml(file_path):
    """从eml文件中提取Date头"""
    try:
        with open(file_path, 'rb') as f:
            msg = BytesParser(policy=policy.default).parse(f)
        
        date_str = msg.get('Date', '')
        return parse_date_to_jst(date_str)
    except Exception as e:
        return f"解析错误: {str(e)}"

# 处理所有文件
results = []
for file in os.listdir(folder):
    if file.endswith('.eml'):
        path = os.path.join(folder, file)
        jst_time = extract_date_from_eml(path)
        results.append([file, jst_time])

# 保存到Excel
df = pd.DataFrame(results, columns=['文件名', '日本时间(JST)'])
df.to_excel(output, index=False)

print(f"完成！已处理 {len(results)} 个文件")
print(f"保存到: {output}")

# 显示前几个结果
print("\n前5个结果:")
for i, (filename, time_str) in enumerate(results[:5]):
    print(f"{i+1}. {filename[:40]:40} → {time_str}")