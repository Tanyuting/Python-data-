import pandas as pd
import os
import re
import sys
from datetime import datetime, timedelta
import email
from email import policy
from email.parser import BytesParser
from email.utils import parsedate_to_datetime, parseaddr

# 检查并安装必要的库
try:
    import pytz
except ImportError:
    print("正在安装pytz库...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pytz"])
    import pytz

folder = r"C:\Users\out-tanyuting\Downloads\test-0331"
output = r"C:\Users\out-tanyuting\Desktop\邮件完整信息0331.xlsx"

def convert_to_jst(dt):
    """转换为日本时间"""
    try:
        if dt.tzinfo is None:
            # 如果没有时区信息，假设是UTC
            dt = dt.replace(tzinfo=pytz.UTC)
        
        # 转换为日本时间
        jst = pytz.timezone('Asia/Tokyo')
        return dt.astimezone(jst)
    except Exception as e:
        print(f"  时区转换错误: {e}")
        return dt

def parse_email_date(date_str):
    """解析邮件日期并转换为日本时间"""
    try:
        # 使用email.utils解析日期（自动处理时区）
        dt = parsedate_to_datetime(date_str)
        # 转换为日本时间
        jst_dt = convert_to_jst(dt)
        return jst_dt
    except Exception as e:
        print(f"  解析邮件日期错误: {e}")
        return None

def extract_sender_info(msg):
    """提取发件人信息"""
    try:
        # 获取From头
        from_header = msg.get('From', '')
        if from_header:
            # 解析为 (姓名, 邮箱) 格式
            name, email_addr = parseaddr(from_header)
            
            # 如果没有姓名但有邮箱，使用邮箱作为显示名
            if not name and email_addr:
                name = email_addr.split('@')[0]
            
            # 格式化发件人信息
            if name and email_addr:
                return f"{name} <{email_addr}>"
            elif email_addr:
                return email_addr
            elif name:
                return name
            else:
                return "未知"
        
        # 尝试其他可能的发件人头
        for header in ['Sender', 'Reply-To', 'Return-Path']:
            value = msg.get(header, '')
            if value:
                name, email_addr = parseaddr(value)
                if email_addr:
                    return f"{name} <{email_addr}>" if name else email_addr
        
        return "未知"
    except Exception as e:
        print(f"  提取发件人错误: {e}")
        return "未知"

def extract_recipients_info(msg):
    """提取收件人信息"""
    try:
        recipients = []
        
        # 获取To头
        to_header = msg.get('To', '')
        if to_header:
            # 可能有多个收件人，用逗号分隔
            for addr in to_header.split(','):
                name, email_addr = parseaddr(addr.strip())
                if email_addr:
                    recipients.append(f"{name} <{email_addr}>" if name else email_addr)
                elif name:
                    recipients.append(name)
        
        # 获取Cc头
        cc_header = msg.get('Cc', '')
        if cc_header:
            for addr in cc_header.split(','):
                name, email_addr = parseaddr(addr.strip())
                if email_addr:
                    recipients.append(f"{name} <{email_addr}> (抄送)" if name else f"{email_addr} (抄送)")
                elif name:
                    recipients.append(f"{name} (抄送)")
        
        # 如果没有收件人，标记为未知
        if not recipients:
            return "未知"
        
        # 合并多个收件人
        return " | ".join(recipients[:3])  # 只显示前3个，避免太长
    except Exception as e:
        print(f"  提取收件人错误: {e}")
        return "未知"

def extract_subject(msg):
    """提取邮件主题"""
    try:
        subject = msg.get('Subject', '')
        if subject:
            return subject.strip()
        return "无主题"
    except Exception as e:
        print(f"  提取主题错误: {e}")
        return "无主题"

def extract_message_id(msg):
    """提取邮件ID"""
    try:
        # 尝试获取Message-ID头
        msg_id = msg.get('Message-ID', '')
        if msg_id:
            # 清理<>符号
            msg_id = msg_id.strip('<>')
            return msg_id
        
        # 尝试获取其他ID
        for header in ['X-MS-Has-Attach', 'X-MS-TNEF-Correlator']:
            value = msg.get(header, '')
            if value:
                return value
        
        return None
    except Exception as e:
        return None

def extract_date_from_eml_file(file_path):
    """从eml文件中提取完整信息"""
    try:
        with open(file_path, 'rb') as f:
            msg = BytesParser(policy=policy.default).parse(f)
        
        print(f"\n处理文件: {os.path.basename(file_path)}")
        
        # 1. 提取发件人
        sender = extract_sender_info(msg)
        print(f"  发件人: {sender[:50] if sender != '未知' else '未知'}")
        
        # 2. 提取收件人
        recipients = extract_recipients_info(msg)
        print(f"  收件人: {recipients[:50] if recipients != '未知' else '未知'}")
        
        # 3. 提取主题
        subject = extract_subject(msg)
        print(f"  主题: {subject[:50]}")
        
        # 4. 提取邮件ID
        message_id = extract_message_id(msg)
        
        # 5. 提取日期并转换为日本时间
        date_str = msg.get('Date', '')
        jst_time = None
        jst_time_str = "未找到日期"
        
        if date_str:
            print(f"  找到Date头: {date_str[:100]}")
            jst_dt = parse_email_date(date_str)
            if jst_dt:
                jst_time = jst_dt
                jst_time_str = jst_dt.strftime("%Y-%m-%d %H:%M:%S")
                print(f"  日本时间: {jst_time_str}")
        
        # 如果Date头解析失败，尝试从内容中查找
        if not jst_time:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read(10000)
            except:
                with open(file_path, 'r', encoding='shift-jis', errors='ignore') as f:
                    content = f.read(10000)
            
            # 查找其他日期格式
            patterns = [
                (r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})', "%Y-%m-%d %H:%M:%S"),
                (r'(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})', "%Y/%m/%d %H:%M:%S"),
                (r'(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})', "%m/%d/%Y %H:%M:%S"),
                (r'(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}:\d{2})', "%m-%d-%Y %H:%M:%S"),
            ]
            
            for pattern, fmt in patterns:
                match = re.search(pattern, content)
                if match:
                    date_str = match.group(1)
                    try:
                        dt = datetime.strptime(date_str, fmt)
                        # 假设是日本时间
                        jst_dt = pytz.timezone('Asia/Tokyo').localize(dt)
                        jst_time = jst_dt
                        jst_time_str = jst_dt.strftime("%Y-%m-%d %H:%M:%S")
                        print(f"  从内容提取时间: {jst_time_str}")
                        break
                    except Exception as e:
                        continue
        
        # 返回完整信息
        return {
            '文件名': os.path.basename(file_path),
            '日本时间(JST)': jst_time_str,
            '发件人': sender,
            '收件人': recipients,
            '主题': subject,
            '邮件ID': message_id if message_id else '',
            '原始文件': file_path
        }
        
    except Exception as e:
        print(f"  文件处理错误: {e}")
        return {
            '文件名': os.path.basename(file_path),
            '日本时间(JST)': "处理错误",
            '发件人': "未知",
            '收件人': "未知",
            '主题': "未知",
            '邮件ID': "",
            '原始文件': file_path
        }

def extract_search_id_from_filename(filename):
    """从文件名中提取搜索ID（用于调试）"""
    patterns = [
        r'\[(mdmswitch_help:\d+)\]',
        r'(\w+:\d+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, filename)
        if match:
            return match.group(1)
    return None

# 主程序
def main():
    print("EML邮件信息提取工具 - 完整版（包含发件人/收件人）")
    print("=" * 80)
    print(f"检查文件夹: {folder}")
    
    if not os.path.exists(folder):
        print(f"错误: 文件夹不存在!")
        input("按Enter键退出...")
        return
    
    files = os.listdir(folder)
    print(f"找到 {len(files)} 个文件")
    
    eml_count = 0
    results = []
    
    # 先统计eml文件
    for file in files:
        if file.lower().endswith('.eml'):
            eml_count += 1
    
    print(f"找到 {eml_count} 个 .eml 文件")
    
    if eml_count == 0:
        print("没有找到 .eml 文件，显示所有文件:")
        for f in files[:20]:
            print(f"  - {f}")
        input("按Enter键退出...")
        return
    
    # 处理每个eml文件
    processed = 0
    for file in files:
        if file.lower().endswith('.eml'):
            processed += 1
            path = os.path.join(folder, file)
            
            print(f"\n[{processed}/{eml_count}] 处理: {file[:60]}")
            
            # 提取完整信息
            info = extract_date_from_eml_file(path)
            results.append(info)
    
    # 创建DataFrame
    df = pd.DataFrame(results)
    
    # 调整列顺序
    columns_order = ['文件名', '日本时间(JST)', '发件人', '收件人', '主题', '邮件ID', '原始文件']
    df = df[columns_order]
    
    # 保存到Excel
    try:
        df.to_excel(output, index=False)
        print(f"\n✓ 成功保存到: {output}")
    except Exception as e:
        print(f"保存Excel失败: {e}")
        csv_output = output.replace('.xlsx', '.csv')
        try:
            df.to_csv(csv_output, index=False, encoding='utf-8-sig')
            print(f"✓ 已保存为CSV: {csv_output}")
        except Exception as e2:
            print(f"保存CSV也失败: {e2}")
    
    print(f"\n完成！共处理 {len(results)} 个文件")
    
    # 特别检查 [mdmswitch_help:08254] 文件
    print("\n=== 特别检查 [mdmswitch_help:08254] 文件 ===")
    found_08254 = False
    for _, row in df.iterrows():
        if "08254" in row['文件名']:
            found_08254 = True
            print(f"文件: {row['文件名']}")
            print(f"提取时间: {row['日本时间(JST)']}")
            print(f"发件人: {row['发件人']}")
            print(f"收件人: {row['收件人']}")
            print(f"主题: {row['主题']}")
            print(f"期望时间: 2026-02-10 13:46:15 (日本时间)")
            
            if row['日本时间(JST)'] == "2026-02-10 13:46:15":
                print("✓ 时间正确！")
            else:
                print("✗ 时间不正确，需要调整")
    
    if not found_08254:
        print("未找到包含08254的文件")
    
    # 显示统计信息
    print(f"\n统计信息:")
    print(f"  总文件数: {len(results)}")
    
    # 时间提取成功率
    time_found = sum(1 for _, row in df.iterrows() 
                    if row['日本时间(JST)'] not in ["未找到日期", "处理错误"])
    print(f"  时间提取成功: {time_found}/{len(results)} ({time_found/len(results)*100:.1f}%)")
    
    # 发件人提取成功率
    sender_found = sum(1 for _, row in df.iterrows() 
                      if row['发件人'] not in ["未知", "处理错误"])
    print(f"  发件人提取成功: {sender_found}/{len(results)} ({sender_found/len(results)*100:.1f}%)")
    
    # 收件人提取成功率
    recipient_found = sum(1 for _, row in df.iterrows() 
                         if row['收件人'] not in ["未知", "处理错误"])
    print(f"  收件人提取成功: {recipient_found}/{len(results)} ({recipient_found/len(results)*100:.1f}%)")
    
    # 显示前5个完整记录
    print(f"\n前5条完整记录:")
    for i in range(min(5, len(df))):
        row = df.iloc[i]
        print(f"\n{i+1}. {row['文件名'][:50]}")
        print(f"   时间: {row['日本时间(JST)']}")
        print(f"   发件人: {row['发件人'][:50]}")
        print(f"   收件人: {row['收件人'][:50]}")
        print(f"   主题: {row['主题'][:50]}")
    
    # 检查是否有同人回复的案例
    print(f"\n=== 检查同人回复案例 (如 mdmswitch_help:14969) ===")
    
    # 按线程ID分组（从文件名提取）
    thread_groups = {}
    for _, row in df.iterrows():
        # 提取线程ID（如 E138）
        match = re.search(r'_([A-Z]\d{3})\.', row['文件名'])
        if match:
            thread_id = match.group(1)
            if thread_id not in thread_groups:
                thread_groups[thread_id] = []
            thread_groups[thread_id].append(row)
    
    # 显示有多个邮件的线程
    for thread_id, emails in thread_groups.items():
        if len(emails) > 1:
            print(f"\n线程 {thread_id}: {len(emails)} 封邮件")
            for email in sorted(emails, key=lambda x: x['日本时间(JST)']):
                print(f"  {email['日本时间(JST)']} - {email['发件人'][:30]} - {email['文件名'][:40]}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"程序错误: {e}")
        import traceback
        traceback.print_exc()
    
    input("\n按Enter键退出...")