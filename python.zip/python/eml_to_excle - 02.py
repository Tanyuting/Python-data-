import pandas as pd
import os
import re
import sys
from datetime import datetime, timedelta
import email
from email import policy
from email.parser import BytesParser
from email.utils import parsedate_to_datetime

# 检查并安装必要的库
try:
    import pytz
except ImportError:
    print("正在安装pytz库...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pytz"])
    import pytz

folder = r"C:\Users\out-tanyuting\Downloads\test-0309"
output = r"C:\Users\out-tanyuting\Desktop\邮件日本时间0309.xlsx"

def convert_to_jst(dt):
    """转换为日本时间"""
    try:
        if dt.tzinfo is None:
            # 如果没有时区信息，假设是UTC
            dt = dt.replace(tzinfo=pytz.UTC)
        
        # 转换为日本时间
        jst = pytz.timezone('Asia/Tokyo')
        return dt.astimezone(jst)
    except Exception as e:
        print(f"  时区转换错误: {e}")
        return dt

def parse_email_date(date_str):
    """解析邮件日期并转换为日本时间"""
    try:
        # 使用email.utils解析日期（自动处理时区）
        dt = parsedate_to_datetime(date_str)
        # 转换为日本时间
        jst_dt = convert_to_jst(dt)
        return jst_dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception as e:
        print(f"  解析邮件日期错误: {e}")
        return None

def extract_date_from_eml_file(file_path):
    """从eml文件中提取日期并转换为日本时间"""
    try:
        with open(file_path, 'rb') as f:
            msg = BytesParser(policy=policy.default).parse(f)
        
        # 获取Date头
        date_str = msg.get('Date', '')
        if date_str:
            print(f"  找到Date头: {date_str[:100]}")
            jst_time = parse_email_date(date_str)
            if jst_time:
                return jst_time
        
        # 如果没有Date头或解析失败，尝试从内容中查找其他日期格式
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(10000)
        except:
            with open(file_path, 'r', encoding='shift-jis', errors='ignore') as f:
                content = f.read(10000)
        
        # 查找其他日期格式（假设是日本时间）
        patterns = [
            r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})',  # 2020-02-10 09:39:38
            r'(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})',  # 2020/02/10 09:39:38
            r'(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})',  # 02/10/2026 13:46:15
            r'(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2}:\d{2})',  # 02-10-2026 13:46:15
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                date_str = match.group(1)
                try:
                    if '-' in date_str and len(date_str.split('-')[0]) == 4:
                        dt = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                    elif '-' in date_str:
                        dt = datetime.strptime(date_str, "%m-%d-%Y %H:%M:%S")
                    elif '/' in date_str and len(date_str.split('/')[0]) == 4:
                        dt = datetime.strptime(date_str, "%Y/%m/%d %H:%M:%S")
                    elif '/' in date_str:
                        # 处理 MM/DD/YYYY HH:MM:SS 格式
                        dt = datetime.strptime(date_str, "%m/%d/%Y %H:%M:%S")
                    else:
                        continue
                    
                    return dt.strftime("%Y-%m-%d %H:%M:%S")
                except Exception as e:
                    print(f"  日期解析错误: {e}")
                    continue
        
        return None
        
    except Exception as e:
        print(f"  文件处理错误: {e}")
        return None

# 主程序
def main():
    print(f"检查文件夹: {folder}")
    
    if not os.path.exists(folder):
        print(f"错误: 文件夹不存在!")
        input("按Enter键退出...")
        return
    
    files = os.listdir(folder)
    print(f"找到 {len(files)} 个文件")
    
    eml_count = 0
    results = []
    
    for file in files:
        if file.endswith('.eml'):
            eml_count += 1
            path = os.path.join(folder, file)
            
            print(f"\n处理文件 {eml_count}: {file[:60]}...")
            
            # 优先从邮件内容提取（正确转换时区）
            date_str = extract_date_from_eml_file(path)
            
            if date_str:
                print(f"  ✓ 提取到时间: {date_str}")
                results.append([file, date_str])
            else:
                print(f"  ✗ 未找到时间信息")
                results.append([file, "未找到日期"])
    
    print(f"\n处理了 {eml_count} 个 .eml 文件")
    
    if eml_count == 0:
        print("没有找到 .eml 文件，显示所有文件:")
        for f in files[:20]:
            print(f"  - {f}")
        input("按Enter键退出...")
        return
    
    # 创建DataFrame
    df = pd.DataFrame(results, columns=['文件名', '日本时间(JST)'])
    
    # 保存到Excel
    try:
        df.to_excel(output, index=False)
        print(f"\n✓ 成功保存到: {output}")
    except Exception as e:
        print(f"保存Excel失败: {e}")
        csv_output = output.replace('.xlsx', '.csv')
        try:
            df.to_csv(csv_output, index=False, encoding='utf-8-sig')
            print(f"✓ 已保存为CSV: {csv_output}")
        except Exception as e2:
            print(f"保存CSV也失败: {e2}")
    
    print(f"\n完成！共处理 {len(results)} 个文件")
    
    # 特别检查 [mdmswitch_help:08254] 文件
    print("\n=== 特别检查 [mdmswitch_help:08254] 文件 ===")
    found_08254 = False
    for file, time_str in results:
        if "08254" in file:
            found_08254 = True
            print(f"文件: {file}")
            print(f"提取时间: {time_str}")
            print(f"期望时间: 2026-02-10 13:46:15 (日本时间)")
            if time_str == "2026-02-10 13:46:15":
                print("✓ 时间正确！")
            else:
                print("✗ 时间不正确，需要调整")
    
    if not found_08254:
        print("未找到包含08254的文件")
    
    print("\n前10个结果:")
    for i, (filename, time_str) in enumerate(results[:10]):
        short_name = filename[:50] + "..." if len(filename) > 50 else filename
        print(f"{i+1:3d}. {short_name:55} → {time_str}")
    
    # 显示统计
    found = sum(1 for _, t in results if t != "未找到日期")
    print(f"\n统计: 成功提取 {found}/{len(results)} 个文件的时间 ({found/len(results)*100:.1f}%)")
    
    input("\n按Enter键退出...")

if __name__ == "__main__":
    main()